﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
var Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000
});

const swalWithBootstrapButtons = Swal.mixin({
    customClass: {
        confirmButton: 'btn btn-success',
        cancelButton: 'btn btn-danger'
    },
    buttonsStyling: false
});

// Define Site public JS Library
(function ($) {
    $.extend({
        site: {
            startload: function (callback) {
                $('body').addClass('loading');
                $("body .loader-container").stop().fadeIn("slow", function () {
                    // Animation complete.
                    if (callback) {
                        return callback();
                    }
                });
            },
            stopload: function (callback) {
                $("body.loading .loader-container").stop().fadeOut("slow", function () {
                    // Animation complete.
                    $('body').removeClass('loading');
                    if (callback) {
                        return callback();
                    }
                });
            },
            confirm: function (title, message, confirm_callback = null, cancel_callback = null, icon = 'warning', showCancelButton = true, confirmButtonText = 'Confirm', cancelButtonText = 'Cancel') {
                swalWithBootstrapButtons.fire({
                    title: title,
                    text: message,
                    icon: icon,
                    showCancelButton: showCancelButton,
                    confirmButtonText: confirmButtonText,
                    cancelButtonText: cancelButtonText,
                    reverseButtons: true
                }).then((result) => {
                    if (result.isConfirmed) {
                        if (confirm_callback) {
                            confirm_callback();
                        }
                    } else {
                        if (cancel_callback) {
                            cancel_callback();
                        }
                    }
                });
            }
        }
    });
})(jQuery);

$(function () {
    // Initialize for Toast
    $(window).bind("load", function () {

        if ($('.validation-summary-errors').length) {

            var listItems = $(".validation-summary-errors > ul li");
            listItems.each(function (idx, li) {
                var item = $(li);
                Toast.fire({
                    icon: 'error',
                    title: $(item).html()
                })
            });
        }

        if ($('.modal-item').length) {
            var modalItem = $(".modal-item");
            var modalStatus = modalItem.attr("data-modal-status");

            Toast.fire({
                icon: modalStatus,
                title: modalItem.html()
            })
        }

        var url = window.location.protocol + "//" + window.location.host + window.location.pathname;

        var element = $('ul.nav a').filter(function () {
            var index_url = window.location.protocol + "//" + window.location.host;
            var is_menu_home = (this.href.replaceAll("/", "") == index_url.replaceAll("/", ""));
            var is_cur_url_home = (url.replaceAll("/", "") == index_url.replaceAll("/", ""));

            var condition1 = this.href == url;
            var condition2 = (is_menu_home && is_cur_url_home) ? true : (url.indexOf(this.href) == 0 && !(this.href.replaceAll("/", "") == index_url.replaceAll("/", "")));

            return (condition1 || condition2);
        }).addClass('active').parent().parent().addClass('in').parent();
        if (element.is('li')) {
            element.addClass('active menu-open');
        }
    });

    $(window).bind("load resize", function () {
        topOffset = 50;
        width = (this.window.innerWidth > 0) ? this.window.innerWidth : this.screen.width;
        if (width < 768) {
            $('div.navbar-collapse').addClass('collapse');
            topOffset = 100; // 2-row-menu
        } else {
            $('div.navbar-collapse').removeClass('collapse');
        }

        height = ((this.window.innerHeight > 0) ? this.window.innerHeight : this.screen.height) - 1;
        height = height - topOffset;
        if (height < 1) height = 1;
        if (height > topOffset) {
            $("#page-wrapper").css("min-height", (height) + "px");
        }
    });
});